"""Finite local discrimination runs using existing receiver probes, not a release gate."""
import json
import os
from pathlib import Path
import subprocess as sp
import sys
import time

ROOT = Path(__file__).resolve().parent
CWD = '/workspace/.tmp/reflection'
PREFIX = 'mptunnel-reflection-'

def command(side, args, **kwargs):
    return sp.run(['docker', 'exec', PREFIX + side + '-1', *args], check=True, **kwargs)

def shape(side, mode, link, rate, loss):
    if side == 'client' and rate == '500mbit':
        rate = os.environ.get('REFLECTION_RETURN_RATE', rate)
    delay, jitter = ('70ms', '20ms') if side == 'server' else ('30ms', '5ms')
    if os.environ.get('REFLECTION_NO_JITTER') == '1':
        jitter = '0ms'
    if os.environ.get('REFLECTION_NO_LOSS') == '1':
        loss = 0
    if os.environ.get('REFLECTION_MIRROR_IMPAIRMENT') == '1':
        side = 'client' if side == 'server' else 'server'
    if os.environ.get('REFLECTION_ROUTED') == '1':
        command('router', ['env', 'REFLECTION_FIFO=' + os.environ.get('REFLECTION_FIFO', '0'), 'bash', CWD + '/shape.sh', mode, '46' if side == 'server' else '47', rate, str(loss) + '%', delay, jitter], stdout=sp.DEVNULL)
    else:
        command(side, ['bash', CWD + '/shape.sh', mode, str(link), rate, str(loss) + '%', delay, jitter], stdout=sp.DEVNULL)

def stop_products():
    for side in ('client', 'server'):
        for name in ('mptunnel', 'hysteria', 'xray'):
            result = sp.run(['docker', 'exec', PREFIX + side + '-1', 'pkill', '-TERM', '-x', name], stdout=sp.DEVNULL, stderr=sp.DEVNULL)
            if result.returncode not in (0, 1):
                raise RuntimeError(f'cannot stop {side}/{name}: {result.returncode}')

def start(side, args, output):
    return sp.Popen(['docker', 'exec', PREFIX + side + '-1', *args], stdout=output, stderr=sp.STDOUT)

def run(system, scenario, direction='down'):
    if system == 'aggregate' and os.environ.get('REFLECTION_ROUTED') == '1':
        raise ValueError('aggregate requires independent endpoint links, not router directions')
    link_rate = os.environ.get('REFLECTION_LINK_RATE', '500mbit')
    label = f'{system}-{scenario}-{direction}-' + os.environ.get('REFLECTION_TAG', 'r1')
    dest = ROOT / 'results' / label
    dest.mkdir(exist_ok=False)
    stop_products()
    processes = []
    logs = []
    for side in ('server', 'client'):
        for link in (46, 47):
            shape(side, 'init', link, link_rate, 3 if side == 'server' else 1)
    if system == 'aggregate' and 'REFLECTION_LINK_RATE' not in os.environ:
        for link, down, up in ((46, '300mbit', '60mbit'), (47, '200mbit', '40mbit')):
            shape('server', 'change', link, down, 3)
            shape('client', 'change', link, up, 1)
    for side in ('server', 'client'):
        args = None
        if system in ('tcp', 'quic', 'mixed', 'aggregate'):
            config = 'server.toml' if side == 'server' else f'client-{system}.toml'
            config = os.environ.get('REFLECTION_' + side.upper() + '_CONFIG', config)
            binary = os.environ.get(f'REFLECTION_{side.upper()}_BINARY',
                                    os.environ.get('REFLECTION_BINARY', CWD + '/bin/current/mptunnel'))
            args = [binary, '--config', config]
            if os.environ.get('REFLECTION_DIAG') == '1':
                events = 'server_sender_dispatch,receive_hole,receive_hole_release,stream_ack_received,server_data_ack_recovery,server_stale_output_recovery,server_response_recovery_wake,server_output_update'
                if os.environ.get('REFLECTION_DIAG_RANK') == '1':
                    events += ',response_data_candidate_evaluated'
                if os.environ.get('REFLECTION_DIAG_REPAIR') == '1':
                    events += ',response_stale_repair_no_target,response_repair_service_rejected,server_repair_carrier_accept,path_writer_drain,server_tcp_write_feedback_interlock,server_tcp_write_input_deferred,tcp_sender_metrics'
                events = os.environ.get('REFLECTION_DIAG_EVENTS', events)
                args = ['env', 'MPTUNNEL_LAB_DIAG=1', 'MPTUNNEL_LAB_ROLE=' + side, 'MPTUNNEL_LAB_DIAG_EVENTS=' + events] + args
                if 'REFLECTION_DIAG_STREAM_ID' in os.environ:
                    args = ['env', 'MPTUNNEL_LAB_STREAM_ID=' + os.environ['REFLECTION_DIAG_STREAM_ID']] + args
            if os.environ.get('REFLECTION_NATIVE_TRACE') == '1':
                args = ['env', 'MPTUNNEL_NATIVE_RECOVERY_TRACE=1'] + args
        elif system == 'h2':
            args = [CWD + '/bin/hysteria', '--disable-update-check', side, '--config', f'h2-{side}.yaml']
        elif system == 'xray':
            args = [CWD + '/bin/xray', 'run', '-c', f'xray-{side}.json']
        if args:
            output = open(dest / f'{side}.log', 'w')
            logs.append(output)
            processes.append(start(side, args, output))
    time.sleep(1)
    if any(p.poll() is not None for p in processes):
        raise RuntimeError(f'{label}: product startup failed; inspect logs')
    target = ('10.238.47.20' if os.environ.get('REFLECTION_ROUTED') == '1' else '10.238.46.20') if system == 'raw' else '127.0.0.1'
    if system == 'raw':
        target = os.environ.get('REFLECTION_RAW_TARGET', target)
    duration = 40 if scenario in ('combined', 'reorder-recovery') else 25
    proxy = [] if system == 'raw' else ['--proxy', '127.0.0.1:1080']
    if direction == 'down':
        probe = ['python3', '/workspace/lab/mixed_workload_probe.py', '--label', label,
                 '--mode', 'direct' if system == 'raw' else 'socks5', '--workload-mode', 'bulk-interactive',
                 '--http-target', target + ':8080', '--tcp-echo-target', target + ':10022',
                 '--load-duration', str(duration), '--timeout', str(duration + 10), '--interval-seconds', '1',
                 '--tcp-echo-timeout-ms', '3000', '--tcp-echo-interval-ms', '500'] + proxy
    else:
        probe = ['python3', '/workspace/lab/bulk_upload_probe.py', '--label', label,
                 '--target', target + ':10023', '--failover-after', '-1', '--load-duration', str(duration),
                 '--timeout', str(duration + 10), '--parallel-uploads', '1', '--interval-seconds', '1'] + proxy
        if os.environ.get('REFLECTION_TARGET_OBSERVE') == '1':
            probe += ['--started-file', CWD + '/results/' + label + '/probe.started']
    result_file = open(dest / 'probe.json', 'w')
    error_file = open(dest / 'probe.err', 'w')
    child = sp.Popen(['docker', 'exec', PREFIX + 'client-1', *probe], stdout=result_file, stderr=error_file)
    start_at = time.monotonic()
    epoch = -1
    blackhole = False
    recovered = False
    forward = [3, 8, 5, 6, 10, 3, 5, 8]
    reverse = [1, 2, .5, 3, 2, .5, 1, 2]
    telemetry = open(dest / 'service.jsonl', 'w')
    try:
        while child.poll() is None:
            elapsed = time.monotonic() - start_at
            next_epoch = min(int(elapsed // 5), 7)
            if scenario == 'reorder-recovery' and not recovered and elapsed >= 8:
                os.environ['REFLECTION_NO_JITTER'] = '1'
                shape('server', 'change', 46, link_rate, 0)
                shape('client', 'change', 46, link_rate, 0)
                recovered = True
            if scenario == 'combined' and next_epoch != epoch:
                epoch = next_epoch
                shape('server', 'change', 46, '10mbit' if 3 <= epoch < 5 and os.environ.get('REFLECTION_NO_QOS') != '1' else link_rate, forward[epoch])
                shape('client', 'change', 46, link_rate, reverse[epoch])
            outage = scenario == 'combined' and 30 <= elapsed < 33 and os.environ.get('REFLECTION_NO_BLACKHOLE') != '1'
            if outage != blackhole:
                for side in ('client', 'server'):
                    for port in ('7443', '18444'):
                        command(side, ['iptables', '-I' if outage else '-D', 'INPUT', '-p', 'udp', '--dport' if side == 'server' else '--sport', port, '-j', 'DROP'])
                blackhole = outage
            sample = {'elapsed': elapsed, 'epoch': epoch, 'udp_blackhole': blackhole, 'jitter_removed': recovered,
                      'mirrored_impairment': os.environ.get('REFLECTION_MIRROR_IMPAIRMENT') == '1'}
            for side in (('server', 'client', 'router') if os.environ.get('REFLECTION_ROUTED') == '1' else ('server', 'client')):
                output = command(side, ['sh', '-c', 'tc -s -j class show dev eth0; tc -s -j class show dev eth1; tc -s -j qdisc show; ps -eo pid,comm,rss,pcpu'], capture_output=True, text=True).stdout
                sample[side] = output
                if os.environ.get('REFLECTION_TARGET_OBSERVE') == '1' and side != 'router':
                    sample[side + '_target_sockets'] = command(side, ['ss', '-tinmp', '( sport = :10023 or dport = :10023 or sport = :1080 or dport = :1080 )'], capture_output=True, text=True).stdout
                    if side == 'server':
                        sample['sink_pid25'] = command(side, ['sh', '-c', 'cat /proc/25/stat /proc/25/status'], capture_output=True, text=True).stdout
                if side != 'router' and os.environ.get('REFLECTION_MANAGEMENT') == '1' and system in ('tcp', 'quic', 'mixed', 'aggregate'):
                    sample[side + '_tcp_sockets'] = command(side, ['ss', '-tinm', '( sport = :7443 or dport = :7443 )'], capture_output=True, text=True).stdout
                    try:
                        snapshot = command(side, ['curl', '-fsS', '--max-time', '2', '-H', 'Authorization: Bearer reflection-public-test', 'http://127.0.0.1:17600/api/v4/status'], capture_output=True, text=True).stdout
                        sample[side + '_management'] = json.loads(snapshot)
                    except Exception as error:
                        sample[side + '_management_error'] = str(error)
            telemetry.write(json.dumps(sample) + '\n')
            telemetry.flush()
            if elapsed > duration + 45:
                raise RuntimeError(f'{label}: probe failed to settle')
            time.sleep(max(0, 1 - (time.monotonic() - start_at - elapsed)))
        print(json.dumps({'case': label, 'returncode': child.returncode, 'elapsed': time.monotonic() - start_at}), flush=True)
    finally:
        if blackhole:
            for side in ('client', 'server'):
                for port in ('7443', '18444'):
                    command(side, ['iptables', '-D', 'INPUT', '-p', 'udp', '--dport' if side == 'server' else '--sport', port, '-j', 'DROP'])
        telemetry.close()
        result_file.close()
        error_file.close()
        stop_products()
        for process in processes:
            try:
                process.wait(timeout=5)
            except sp.TimeoutExpired:
                raise RuntimeError('graceful process teardown still pending; stop owned containers before next case')
        for log in logs:
            log.close()
    if child.returncode:
        raise RuntimeError(f'{label}: receiver probe failed')
    if scenario == 'reorder-recovery':
        os.environ.pop('REFLECTION_NO_JITTER', None)

if __name__ == '__main__':
    for system in sys.argv[1].split(','):
        run(system, sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else 'down')
