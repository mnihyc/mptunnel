#!/usr/bin/env bash
set -euo pipefail
exec env -u MPTUNNEL_LAB_STREAM_ID \
  MPTUNNEL_LAB_TCP_REFILL_DISABLED=0 \
  MPTUNNEL_LAB_PERF=1 MPTUNNEL_LAB_PERF_SAMPLES=0 \
  /workspace/.tmp/reflection/bin/native-refill-copy-20260910/mptunnel "$@"
