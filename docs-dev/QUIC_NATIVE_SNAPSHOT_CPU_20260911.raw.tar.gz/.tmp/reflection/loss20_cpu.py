"""Observation-only DOWN loss / 0% UP control using the unchanged runner.

CPU records describe Linux process/thread ticks, not Rust async tasks or code
attribution. Adjacent stable identities give interval CPU; ps remains lifetime
CPU. No separate polling loop, runtime instrumentation or runner edits.
"""
import argparse
import importlib.util
import os
from pathlib import Path
import shlex


TC_PS_COMMAND = (
    "tc -s -j class show dev eth0; tc -s -j class show dev eth1; "
    "tc -s -j qdisc show; ps -eo pid,comm,rss,pcpu"
)
CPU_COLLECTOR = r'''
import json
import os
from pathlib import Path
import subprocess
import time

def stamp():
    return dict(monotonic_ns=time.monotonic_ns(),
                boottime_ns=time.clock_gettime_ns(time.CLOCK_BOOTTIME),
                unix_ns=time.time_ns())

def read_stat(path):
    begin = stamp()
    raw = path.read_text()
    end = stamp()
    left, right = raw.index('('), raw.rindex(')')
    fields = raw[right + 2:].split()  # starts at stat field 3 (state)
    return dict(id=int(raw[:left].strip()), comm=raw[left + 1:right],
                utime_ticks=int(fields[11]), stime_ticks=int(fields[12]),
                starttime_ticks=int(fields[19]),
                read_begin=begin, read_end=end)

record = dict(schema='mptunnel.loss20.cpu.v1', begin=stamp(), processes=[], errors=[])
try:
    record['clock_ticks_per_second'] = os.sysconf('SC_CLK_TCK')
    record['boot_id'] = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    found = subprocess.run(['pgrep', '-x', 'mptunnel'], capture_output=True, text=True)
    if found.returncode not in (0, 1):
        raise RuntimeError('pgrep returncode ' + str(found.returncode))
    pids = sorted(int(value) for value in found.stdout.split())
    record['matched_processes'] = len(pids)
    for pid in pids:
        entry = dict(pid=pid, tasks=[], errors=[])
        record['processes'].append(entry)
        try:
            root = Path('/proc') / str(pid)
            entry['process'] = read_stat(root / 'stat')
            for task in sorted((root / 'task').iterdir(), key=lambda p: int(p.name)):
                try:
                    entry['tasks'].append(read_stat(task / 'stat'))
                except (OSError, ValueError, IndexError) as error:
                    entry['errors'].append(dict(tid=int(task.name), error=str(error)))
            identity_after = read_stat(root / 'stat')
            entry['identity_stable'] = (
                entry['process']['id'], entry['process']['starttime_ticks']
            ) == (identity_after['id'], identity_after['starttime_ticks'])
        except (OSError, ValueError, IndexError) as error:
            entry['errors'].append(dict(error=str(error)))
except Exception as error:
    record['errors'].append(str(error))
record['end'] = stamp()
print('MPTUNNEL_CPU_TICKS ' + json.dumps(record, separators=(',', ':')))
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('system', choices=('quic', 'mixed'))
    parser.add_argument('direction', choices=('down', 'up'))
    parser.add_argument('--forward-loss', type=int, choices=(0, 20), default=20,
                        help='20%% reported-loss case or matched 0%% control')
    args = parser.parse_args()
    for name in ('REFLECTION_MIRROR_IMPAIRMENT', 'REFLECTION_ROUTED', 'REFLECTION_NO_LOSS'):
        if os.environ.get(name) not in (None, '', '0'):
            parser.error(name + ' must be unset or 0')
    for name in ('REFLECTION_NO_QOS', 'REFLECTION_NO_BLACKHOLE'):
        if os.environ.get(name) != '1':
            parser.error(name + '=1 must be explicitly supplied')

    spec = importlib.util.spec_from_file_location('loss20_existing_runner', Path(__file__).with_name('run.py'))
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    original_shape, original_command = runner.shape, runner.command

    def fixed_loss(side, mode, link, rate, loss):
        return original_shape(side, mode, link, rate, args.forward_loss if side == 'server' else 0)

    def observed_command(side, command_args, **kwargs):
        if side in ('server', 'client') and command_args == ['sh', '-c', TC_PS_COMMAND]:
            # Keep the original command's status; observation failure is data,
            # not a replacement success/failure for the existing tc/ps command.
            extended = (TC_PS_COMMAND + '\nloss20_status=$?\npython3 -c '
                        + shlex.quote(CPU_COLLECTOR) + '\nexit "$loss20_status"')
            command_args = ['sh', '-c', extended]
        return original_command(side, command_args, **kwargs)

    runner.shape, runner.command = fixed_loss, observed_command
    runner.run(args.system, 'combined', args.direction)


if __name__ == '__main__':
    main()
