#!/usr/bin/env bash
set -euo pipefail
exec env MPTUNNEL_LAB_PERF=1 \
  /workspace/.tmp/reflection/bin/bulk-original-placement-20260909/mptunnel "$@"
