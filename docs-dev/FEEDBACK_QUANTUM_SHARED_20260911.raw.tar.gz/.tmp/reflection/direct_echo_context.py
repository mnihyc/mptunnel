"""Reuse the existing direct echo worker beside a bounded, unchanged MPP run."""
import argparse
import json
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "lab"))
from mixed_workload_probe import interactive_tcp_worker

parser = argparse.ArgumentParser()
parser.add_argument("--label", required=True)
opts = parser.parse_args()
args = SimpleNamespace(
    mode="direct", tcp_echo_target="10.238.47.20:10022",
    tcp_echo_timeout_ms=3000, tcp_echo_payload_bytes=64,
    tcp_echo_interval_ms=500, load_duration=50.0, timeout=53.0,
    failover_after=-1.0,
)
started_at = time.monotonic()
started_unix_ns = time.time_ns()
result = {"label": opts.label, "mode": "direct", "target": args.tcp_echo_target,
          "started_monotonic_s": started_at, "started_unix_ns": started_unix_ns,
          "observation_s": args.load_duration}
print(json.dumps({"event": "direct_echo_started", **result}), flush=True)
interactive_tcp_worker(args, started_at, threading.Event(), result)
print(json.dumps({"event": "direct_echo_complete", **result}), flush=True)
