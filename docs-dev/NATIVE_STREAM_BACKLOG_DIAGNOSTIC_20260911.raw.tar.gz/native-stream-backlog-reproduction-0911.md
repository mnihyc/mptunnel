# Native stream backlog discriminator

2026-09-11. Observation only; not a controller or recovery candidate.

Base commit efed8ec (04f recovery runtime plus the requested20% defaults).
Apply native-stream-backlog-0911.patch, which temporarily sets both defaults
back to10 solely to match the existing isolated-link comparator. Compile with
`cargo build --release --features lab-diagnostics -j 4`; final build1m33s.
The initial observer build refused private StreamsState.unacked_data access;
the getter now obtains that field inside its owning module. This was an
observer compile error, not a Product failure or mechanism RED.
The existing unused apply_and_write_ready_stream_data_batch warning remains;
the only caller is a test. It belongs to the pending release-quality gate.

Freeze target/release/mptunnel as bin/native-stream-backlog-20260911/mptunnel.
Reverse the complete observer patch before traffic: committed product source
returns to20%, with no diagnostic getter/consumer left. The explicit frozen
binary remains10%; target/release is an observer, never the ordinary candidate.

Run the existing run.py aggregate combined down once, with:

```sh
env -u REFLECTION_NO_QOS -u REFLECTION_NO_BLACKHOLE \
 -u REFLECTION_ROUTED -u REFLECTION_SERVER_BINARY -u REFLECTION_CLIENT_BINARY \
 -u REFLECTION_NATIVE_TRACE -u REFLECTION_MIRROR_IMPAIRMENT \
 -u REFLECTION_SERVER_CONFIG \
 REFLECTION_BINARY=/workspace/.tmp/reflection/bin/native-stream-backlog-20260911/mptunnel \
 REFLECTION_CLIENT_CONFIG=client-isolated-tcp47-quic46.toml \
 REFLECTION_LINK_RATE=200mbit REFLECTION_NO_LOSS=1 REFLECTION_NO_JITTER=1 \
 REFLECTION_MANAGEMENT=1 REFLECTION_TARGET_OBSERVE=1 \
 REFLECTION_DIAG=1 REFLECTION_DIAG_EVENTS=quic_stream_backlog \
 REFLECTION_TAG=isolated-tcp47-quic46-native-backlog-0911 \
 python3 .tmp/reflection/run.py aggregate combined down
```

Each native snapshot sums offset−unsent over non-reset send streams, under
one Quinn state lock. This is never-packetized stream payload, excluding
retransmission requests. unacked_stream_bytes includes sent/unacknowledged
payload; native_flight_bytes is active-path packet flight. api_write_bytes
is a separate atomic sampled immediately afterward, not the same state lock.
Counters cover the connection, not solely the bulk stream. An API-zero snapshot
therefore demonstrates the reporting boundary but is not exact per-byte residence.
The getter is called only by the enabled periodic diagnostic, never rank,
admission or the per-packet scheduling snapshot. It scans native send entries;
even observation can perturb timing. Do not promote its Mbps as ordinary evidence.

Keep both endpoints' raw logs, full receiver probe/error and service.jsonl;
sort diagnostics by numeric seq per process. Verify unsigned values,
unsent<=unacked, sample counts, full run exit/teardown and physical schedule.
Large persistent unsent storage supports the pre-packet-residence hypothesis;
small storage rejects that stage explanation. Neither result itself licenses
a smaller window, another pacer or the previously adverse repair pipeline.
