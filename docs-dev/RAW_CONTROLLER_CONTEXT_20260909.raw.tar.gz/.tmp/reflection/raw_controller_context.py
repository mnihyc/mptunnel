"""Compose canonical probe workers to observe one/three native TCP senders."""
import argparse
import json
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "lab"))
from mixed_workload_probe import bulk_worker, interactive_tcp_worker

parser = argparse.ArgumentParser()
parser.add_argument("--streams", type=int, choices=(1, 3), required=True)
opts = parser.parse_args()
args = SimpleNamespace(
    mode="direct", http_target="10.238.47.20:8080", bulk_path="/large.bin",
    tcp_echo_target="10.238.47.20:10022", tcp_echo_timeout_ms=3000,
    tcp_echo_payload_bytes=64, tcp_echo_interval_ms=500,
    load_duration=40.0, timeout=50.0, failover_after=-1.0,
    interval_seconds=1.0, chunk_bytes=64 * 1024,
)
started_at = time.monotonic()
started_unix_ns = time.time_ns()
interactive_ready = threading.Event()
interactive = {}
bodies = [{} for _ in range(opts.streams)]
threads = [threading.Thread(target=interactive_tcp_worker,
                            args=(args, started_at, interactive_ready, interactive))]
threads += [threading.Thread(target=bulk_worker,
                             args=(args, started_at, interactive_ready,
                                   threading.Event(), body)) for body in bodies]
identity = {"streams": opts.streams, "started_monotonic_s": started_at,
            "started_unix_ns": started_unix_ns, "observation_s": 40.0}
print(json.dumps({"event": "raw_context_started", **identity}), flush=True)
for thread in threads:
    thread.start()
for thread in threads:
    thread.join()
print(json.dumps({"event": "raw_context_complete", **identity,
                  "elapsed_s": time.monotonic() - started_at,
                  "bodies": bodies, "interactive": interactive}), flush=True)
