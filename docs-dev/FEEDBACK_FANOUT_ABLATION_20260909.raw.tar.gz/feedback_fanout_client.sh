#!/usr/bin/env bash
set -euo pipefail
# Diagnostic intervention only; independent TCP feedback is disabled here.
exec env MPTUNNEL_LAB_FEEDBACK_ABLATION=quic-only /workspace/.tmp/reflection/bin/feedback-fanout-20260909/mptunnel "$@"
