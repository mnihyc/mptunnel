#!/usr/bin/env bash
set -euo pipefail
exec env -u MPTUNNEL_LAB_ECHO_QUIC_MEMBERSHIP -u MPTUNNEL_LAB_BULK_QUIC_ORIGINALS \
  -u MPTUNNEL_LAB_SUPPRESS_LIVE_RESPONSE_REPAIR \
  MPTUNNEL_LAB_PERF=1 MPTUNNEL_LAB_PERF_SAMPLES=0 \
  /workspace/.tmp/reflection/bin/tcp-product-evidence-20260909/mptunnel "$@"
