#!/usr/bin/env bash
set -euo pipefail
# Information-only first-poll observer; existing aggregate perf summaries only.
exec env MPTUNNEL_LAB_PERF=1 MPTUNNEL_LAB_PERF_SAMPLES=0 /workspace/.tmp/reflection/bin/write-first-poll-20260909/mptunnel "$@"
