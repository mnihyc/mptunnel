#!/usr/bin/env bash
set -euo pipefail
# Unsafe diagnostic intervention: withhold client TCP Data ACK, retain TCP MAX.
exec env MPTUNNEL_LAB_FEEDBACK_ABLATION=tcp-ack-withheld /workspace/.tmp/reflection/bin/feedback-kinds-20260909/mptunnel "$@"
