#!/usr/bin/env bash
set -euo pipefail
# Unsafe diagnostic intervention: withhold client TCP MAX, retain TCP Data ACK.
exec env MPTUNNEL_LAB_FEEDBACK_ABLATION=tcp-max-withheld /workspace/.tmp/reflection/bin/feedback-kinds-20260909/mptunnel "$@"
