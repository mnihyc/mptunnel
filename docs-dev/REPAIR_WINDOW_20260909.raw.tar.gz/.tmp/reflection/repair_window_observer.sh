#!/usr/bin/env bash
set -euo pipefail
exec env -u MPTUNNEL_LAB_ECHO_QUIC_MEMBERSHIP -u MPTUNNEL_LAB_BULK_QUIC_ORIGINALS \
  MPTUNNEL_LAB_PERF=1 MPTUNNEL_LAB_PERF_SAMPLES=0 \
  /workspace/.tmp/reflection/bin/repair-window-20260909/mptunnel "$@"
