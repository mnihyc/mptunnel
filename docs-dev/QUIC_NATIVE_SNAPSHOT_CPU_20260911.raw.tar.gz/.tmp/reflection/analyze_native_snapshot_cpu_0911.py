"""Read-only analysis of the two closed native-snapshot CPU captures.

Process CPU uses each stat's own monotonic midpoint, stable PID/starttime and
CLK_TCK. Perf interval_ms is a configured period, NOT a measured denominator.
Snapshot totals are nonnested complete endpoint CPU; clock-error records are
counts only. This program neither runs a workload nor changes its input files.
"""
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CASES = {
    "invalid_unrecorded": "quic-combined-down-native-snapshot-cpu-twenty-quic-0911",
    "recorded": "quic-combined-down-native-snapshot-cpu-recorded-twenty-quic-0911",
}


def midpoint(stat, field="monotonic_ns"):
    return (stat["read_begin"][field] + stat["read_end"][field]) / 2 / 1e9


def ticks(stat):
    return stat["utime_ticks"] + stat["stime_ticks"]


def read_cpu(row, role):
    line = next(x for x in row[role].splitlines() if x.startswith("MPTUNNEL_CPU_TICKS "))
    record = json.loads(line.split(" ", 1)[1])
    assert not record["errors"] and record["matched_processes"] == 1
    process = record["processes"][0]
    assert not process["errors"] and process["identity_stable"]
    return record, process


def summarize_role(rows, path, role):
    readings = [read_cpu(row, role) for row in rows]
    identities = {(r["boot_id"], p["pid"], p["process"]["starttime_ticks"]) for r, p in readings}
    assert len(identities) == 1
    clocks = {r["clock_ticks_per_second"] for r, _ in readings}
    assert clocks == {100}
    intervals, threads = [], []
    for i, ((_, a), (_, b)) in enumerate(zip(readings, readings[1:])):
        duration = midpoint(b["process"]) - midpoint(a["process"])
        cpu = (ticks(b["process"]) - ticks(a["process"])) / 100
        assert duration > 0 and cpu >= 0
        intervals.append(dict(index=i, runner_start=rows[i]["elapsed"],
                              runner_end=rows[i + 1]["elapsed"], seconds=duration,
                              cpu_seconds=cpu, cpu_percent=100 * cpu / duration,
                              start_unix=midpoint(a["process"], "unix_ns"),
                              end_unix=midpoint(b["process"], "unix_ns")))
        previous = {(x["id"], x["starttime_ticks"]): x for x in a["tasks"]}
        for task in b["tasks"]:
            key = (task["id"], task["starttime_ticks"])
            if key in previous:
                old = previous[key]
                duration = midpoint(task) - midpoint(old)
                cpu = (ticks(task) - ticks(old)) / 100
                assert duration > 0 and cpu >= 0
                threads.append(dict(index=i, tid=task["id"], starttime=task["starttime_ticks"],
                                    cpu_percent=100 * cpu / duration))
    def band(items):
        duration = sum(x["seconds"] for x in items)
        cpu = sum(x["cpu_seconds"] for x in items)
        return dict(cpu_seconds=cpu, observed_seconds=duration, mean_percent=100 * cpu / duration,
                    max_percent=max(x["cpu_percent"] for x in items))
    log = (path / f"{role}.log").read_text()
    perf = []
    for line in log.splitlines():
        if not line.startswith("mptunnel_lab_perf "):
            continue
        fields = dict(re.findall(r"(\w+)=([^ ]+)", line))
        if fields["component"].startswith("transport.quic.snapshot_"):
            perf.append({k: int(v) if v.isdigit() else v for k, v in fields.items()})
    components = {}
    for name in sorted({x["component"] for x in perf}):
        records = [x for x in perf if x["component"] == name]
        assert sum(x["interval_count"] for x in records) == records[-1]["total_count"]
        assert sum(x["interval_total_us"] for x in records) == records[-1]["total_us"]
        assert all(x["interval_bytes"] == x["total_bytes"] == 0 for x in records)
        components[name] = dict(last=records[-1], records=records)
    grouped = defaultdict(lambda: dict(count=0, cpu_us=0, max_us=0))
    for record in perf:
        if record["component"].endswith("_cpu"):
            value = grouped[record["ts_unix_ms"]]
            value["count"] += record["interval_count"]
            value["cpu_us"] += record["interval_total_us"]
            value["max_us"] = max(value["max_us"], record["interval_max_us"])
    brackets = [(s["read_end"]["monotonic_ns"] - s["read_begin"]["monotonic_ns"]) / 1e6
                for _, p in readings for s in [p["process"], *p["tasks"]]]
    cpu_records = [x for x in perf if x["component"].endswith("_cpu")]
    return dict(process_identity=[str(x) for x in identities], samples=len(readings),
                whole=band(intervals), late_30_40=band(intervals[30:40]),
                startup_0_5=band(intervals[:5]), peak=max(intervals, key=lambda x: x["cpu_percent"]),
                hottest_thread=max(threads, key=lambda x: x["cpu_percent"]),
                max_stat_bracket_ms=max(brackets),
                collector_max_ms=max((r["end"]["monotonic_ns"] - r["begin"]["monotonic_ns"])
                                     / 1e6 for r, _ in readings),
                snapshot_count=sum(x["interval_count"] for x in cpu_records),
                snapshot_cpu_us=sum(x["interval_total_us"] for x in cpu_records),
                clock_error_count=sum(x["interval_count"] for x in perf
                                      if x["component"].endswith("_clock_error")),
                components=components, intervals=intervals,
                flush_groups=[dict(end_unix_ms=k, **v) for k, v in sorted(grouped.items())])


def analyze(case):
    path = ROOT / "results" / case
    rows = [json.loads(line) for line in (path / "service.jsonl").read_text().splitlines()]
    probe = json.loads((path / "probe.json").read_text())
    attempts = probe["interactive_attempt_series"]
    raw = probe["bulk_interval_goodput_raw_mbps"]
    summary = dict(case=case, rows=len(rows), runner_elapsed_last=rows[-1]["elapsed"],
                   probe={k: v for k, v in probe.items() if k not in
                          {"interactive_attempt_series", "bulk_interval_goodput_mbps"}},
                   attempt_outcomes=dict(Counter(x["outcome"] for x in attempts)),
                   failed_attempts=[x for x in attempts if x["outcome"] != "success"],
                   phases={f"{a}-{b}": sum(raw[a:b]) / (b-a)
                           for a, b in [(0, 5), (5, 15), (15, 25), (25, 40), (30, 40)]})
    for role in ("client", "server"):
        summary[role] = summarize_role(rows, path, role)
        native = []
        class_rows = []
        rss = []
        for row in rows:
            lines = row[role].splitlines()
            classes = [json.loads(lines[0]), json.loads(lines[1])]
            qdiscs = json.loads(lines[2])
            assert all(c["rate"] == c["ceil"] == 62_500_000 and c["burst"] == 65536
                       for interface in classes for c in interface)
            netem = [q for q in qdiscs if q["kind"] == "netem"]
            assert all(q["options"]["limit"] == 8192 and
                       q["options"]["delay"]["jitter"] == 0 and
                       q["options"]["delay"]["delay"] == (0.07 if role == "server" else 0.03) and
                       q["options"].get("loss-random", {}).get("loss", 0) ==
                       (0.2 if role == "server" else 0) for q in netem)
            assert not row["udp_blackhole"] and not row["mirrored_impairment"]
            active = classes[0 if role == "server" else 1][0]["stats"]
            class_rows.append(active)
            rss.extend(int(m.group(1)) for line in lines
                       if (m := re.match(r"\s*\d+\s+mptunnel\s+(\d+)\s+", line)))
            paths = row[role + "_management"]["paths"]
            native.append([dict(endpoint=p.get("endpoint", p.get("peer")), path=p.get("path"),
                                instance=p.get("path_instance_id"), native=p["native_delivery"],
                                window=p.get("inflight_limit_bytes"), srtt=p.get("srtt_ms"),
                                rate=p.get("pacing_rate_bps"))
                           for p in paths if p.get("native_delivery")])
        summary[role]["wire"] = dict(bytes=class_rows[-1]["bytes"] - class_rows[0]["bytes"],
                                      drops=class_rows[-1]["drops"] - class_rows[0]["drops"],
                                      max_backlog=max(x["backlog"] for x in class_rows),
                                      rss_peak_kib=max(rss), rss_final_kib=rss[-1])
        summary[role]["native"] = native
    return summary


if __name__ == "__main__":
    print(json.dumps({name: analyze(case) for name, case in CASES.items()}, indent=2))
