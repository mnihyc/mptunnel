# Reproduce the closed uncovered-proof classification

Scope: read-only analysis of
`./.tmp/reflection/results/aggregate-combined-down-isolated-tcp47-quic46-uncovered-proof-0911/`.
No Product change, test, traffic, timing threshold or new measurement is needed.
The rejected runtime is `ec8cd2f` plus the archived
`response-uncovered-proof-observer-0911.patch`; the latter adds exact
`received_ranges` and `stored_gaps` to the existing server ACK event.

## Parse and order

1. Read `server.log` as text, retaining `mptunnel_lab_diag` records only. Parse
   scalar `key=value` fields; parse each Debug range list with
   `OffsetRange \{ start: (\d+), end: (\d+) \}`. Bound the `received_ranges`
   and `stored_gaps` substrings separately, not all ranges on the line together.
2. Parse numeric `seq`, `ts_unix_ms`, `pid` and `stream_id`. Sort by numeric
   `seq`, NOT physical file order or wall time. Server sequences are exactly
   1..36631, but the file has four sequence reversals; client sequences are
   exactly1..80850, with six file-order reversals.
3. Server PID is572892. Filter bulk `stream_id=1`; the sole recorded session
   on its copy admissions is528831491406641683. Stream0 is the echo and is
   excluded. There are21335bulk ACK records and15221bulk copy admissions.
4. Use only `server_repair_carrier_accept` as actual admitted copy records.
   Preserve `cause`, exact target identity, `[offset,end)`, and timestamp.
   Assert `end-offset == payload_bytes`. Formed frames, queue readiness or
   skipped/default retained outcomes are NOT actual copy admissions.

## Replay positive and authoritative omission knowledge

All intervals are half-open. `normalize` sorts by start, discards empty ranges,
and unions overlapping OR touching intervals; `subtract(X,Y)` is exact set
difference. Start with cumulative positive set P=[] and omission set G=[].
For each bulk `stream_ack_received` in sequence order:

```text
R = received_ranges
assert R is sorted, nonempty intervals and nonoverlapping
P = normalize(P union R)
G = subtract(G, R)
if scope_start is Some(s):
    E = end of the last received range
    G = normalize(G union subtract([s,E), P))
assert G == logged stored_gaps
```

`scope_start=None` adds no negative authority. Do not treat `largest_end` or
an unscoped positive-only ACK as evidence of omitted bytes. The independent
replay matches all21335logged gap sets with zero mismatches.

At each actual bulk copy, use only the latest preceding ACK/G in numeric
server sequence order. Check `intersection(copy,P)` is empty. Classify:

```python
inside_bytes = sum(max(0, min(copy_end, end) - max(copy_start, start))
                   for start, end in G)
outside_bytes = copy_end - copy_start - inside_bytes
kind = ("outside" if inside_bytes == 0 else
        "inside" if outside_bytes == 0 else "crossing")
```

Require normalized disjoint G before summing. Retain an explicit unknown
class if no preceding ACK exists rather than inventing an empty G. This
capture has no unknown or crossing copies and no copy overlapping previously
applied positives. Sequence ordering identifies the retained observed state;
post-operation event timestamps are not exact native admission timestamps.

## Exact expected totals and conservative wall bands

Count raw copy records/bytes, not distinct DSNs: repetitions remain costs.

| Whole bulk cause |Bytes|Inside G|Outside G|
|---|---:|---:|---:|
| tail,13308records |466558710|412069230|54489480|
| stale,1881records |100242344|72992380|27249964|
| persistent,30records |416730|416730|0|
| ack_gap,2records |65536|65536|0|
| Total,15221records |567283320|485543876|81739444|

Cause aliases are `tail_reinjection`, `stale_path_reinjection`,
`persistent_ack_gap_reinjection` and `ack_gap_reinjection`, respectively;
do not combine the separate persistent and ACK-gap labels in raw counts.
Use half-open server wall-time bands, independent of sequence ordering:

| Band |Exact Unix ms [start,end)|Records/bytes|Inside/outside bytes|
|---|---|---:|---:|
| Approx healthy5–15 |[1789095436839,1789095446839)|6805/209669320|192508728/17160592|
| Strict healthy6–14 |[1789095437839,1789095445841)|5767/175485104|164958704/10526400|
| Approx QoS15–25 |[1789095446839,1789095456839)|1428/78148016|61519888/16628128|
| Strict QoS16–24 |[1789095447839,1789095455840)|1024/53173712|36545584/16628128|

Strict healthy tail alone:5579records/165361472B,154835072inside,
10526400outside. Strict QoS tail:112records/6247528B,349416inside,
5898112outside. Approx healthy tail:6615/199516488B,182355896inside;
approx QoS tail:310/18014600B,12116488inside. These management-clock bands
are NOT exact probe phases; this DOWN capture has no started-file wall anchor.

## Earlier receiver-prefix corroboration: lower bound only

From `client.log`, bulk stream1 `receive_hole` supplies `next_offset` and
`receive_hole_release` supplies `frontier_after`. Sort by `(ts_unix_ms,seq)`;
retain cumulative maximum F. For each server copy, use only client samples
whose wall timestamp is STRICTLY smaller than the copy's timestamp. Count
`max(0, min(copy_end,F)-copy_start)`; same-millisecond evidence is excluded.

Strict healthy tail has5297656B/165361472B=3.203682% below a strictly earlier
ordered frontier; all those bytes are also inside server G. There are163fully
covered tail-copy records, first-cover lead median/p95/max150/181/189ms.
Whole-copy lower bound is48495975B=8.548810%. This misses out-of-order receipts
and unlogged ordinary contiguous progress: the remainder is NOT proven absent,
necessary or useful. Never derive all receiver receipt from positive F alone.

Example: server seq9944 tail[195241012,195249364), TCP2/incarnation2, is logged
at1789095441363ms. Preceding ACK seq9900 at1789095441278ms has covering
G[194013332,199894068). Client first known full-prefix coverage is at
1789095441213ms; its strictly earlier latestF is198835316. This demonstrates
inside-G work can already be received while positive feedback is in transit,
not that the sender violated its applied ACK authority.

For the same suffix, first server G is seq8655 at1789095440225ms. TCP1/
incarnation1 copies1888+6464B at1789095440981ms, seq9618/9619, with logged
remaining copy suppression316533us. Client seq27721 at1789095441213ms
receives earlier frame[194980756,195001108) and releases ordered F from
194980756 to195634228. Because the selected suffix lies beyond this incoming
frame's end, it was already buffered in reorder before this release. This
is a lower-bound receipt witness, not its first-arrival timestamp or winning
Original/copy provenance. The later seq9944copy follows the known release150ms
and the first copies' suppression interval; no D-tuning conclusion follows.
`receive_hole` lacks incoming extent; `receive_hole_release` requires buffered
reorder and frontier advance. No such event does not mean no arrival.

Conclusion reproduced: a simple ban on tail copies outside G cannot remove
the dominant healthy copy volume, because93.6343% of healthy tail bytes are
inside G. This falsifies that proposed easy explanation, not every possible
policy distinction, and recommends no second runtime candidate.
