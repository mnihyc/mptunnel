#!/bin/sh
# Enable the existing periodic recorder in the product container, not its host.
exec env MPTUNNEL_LAB_PERF=1 MPTUNNEL_LAB_PERF_SAMPLES=0 \
  /workspace/.tmp/reflection/bin/native-snapshot-cpu-20260911/mptunnel "$@"
