#!/usr/bin/env bash
set -euo pipefail
action="$1"
link="$2"
rate="$3"
loss="$4"
delay="$5"
jitter="$6"
interface="$(ip -o -4 addr show | awk -v prefix="10.238.${link}." 'index($4,prefix)==1 {print $2}')"
test -n "$interface"
delay_args=(delay "$delay")
if [[ "$jitter" != 0ms ]]; then
  delay_args+=("$jitter" distribution normal)
fi
if [[ "$action" == init ]]; then
  if tc qdisc show dev "$interface" | grep 'qdisc htb' >/dev/null; then
    tc qdisc del dev "$interface" root
  fi
  tc qdisc replace dev "$interface" root handle 1: htb default 10
  tc class replace dev "$interface" parent 1: classid 1:10 htb rate "$rate" ceil "$rate" burst 64k cburst 64k
  tc qdisc replace dev "$interface" parent 1:10 handle 10: netem limit 8192 "${delay_args[@]}" loss random "$loss"
  if [[ "${REFLECTION_FIFO:-0}" == 1 ]]; then
    tc qdisc add dev "$interface" parent 10:1 handle 100: pfifo limit 8192
  fi
else
  tc class change dev "$interface" parent 1: classid 1:10 htb rate "$rate" ceil "$rate" burst 64k cburst 64k
  tc qdisc change dev "$interface" parent 1:10 handle 10: netem limit 8192 "${delay_args[@]}" loss random "$loss"
fi
