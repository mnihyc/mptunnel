"""Finite, header-only receive-side observation for the owned reflection lab.

No packet bodies or identities are retained. Offload is unchanged; lengths
describe received IPv4 SKBs, not an asserted physical wire packetization.
"""
import collections
import json
import socket
import struct
import time

observer = socket.socket(socket.AF_PACKET, socket.SOCK_DGRAM, socket.htons(0x0800))
observer.bind(('eth0', 0))
observer.settimeout(0.2)
source = socket.inet_aton('10.238.46.10')
target = socket.inet_aton('10.238.47.20')
started = time.monotonic()
report_at = started + 1
counts = collections.defaultdict(collections.Counter)
payload_bytes = collections.Counter()
invalid_lengths = 0

def report():
    global counts, payload_bytes, invalid_lengths
    # PACKET_STATISTICS resets its counters on read. It includes filtered
    # traffic too, so drops bound observation loss, not product/network loss.
    packets, drops = struct.unpack('II', observer.getsockopt(263, 6, 8))
    print(json.dumps({
        'unix_ms': time.time_ns() // 1000000,
        'elapsed_s': time.monotonic() - started,
        'ip_length_counts': dict(counts),
        'transport_payload_bytes': dict(payload_bytes),
        'invalid_lengths': invalid_lengths,
        'socket_packets': packets,
        'socket_drops': drops,
    }), flush=True)
    counts = collections.defaultdict(collections.Counter)
    payload_bytes = collections.Counter()
    invalid_lengths = 0

while time.monotonic() - started < 45:
    try:
        header, address = observer.recvfrom(96)
    except socket.timeout:
        header = b''
    if len(header) >= 28 and address[2] != socket.PACKET_OUTGOING:
        ihl = (header[0] & 15) * 4
        length = int.from_bytes(header[2:4], 'big')
        if (header[0] >> 4 == 4 and header[12:16] == source
                and header[16:20] == target and ihl >= 20
                and len(header) >= ihl + 8
                and int.from_bytes(header[ihl+2:ihl+4], 'big') in (7443, 18444)):
            proto = header[9]
            transport_header = (header[ihl+12] >> 4) * 4 if proto == 6 and len(header) > ihl+12 else 8
            if length < ihl + transport_header or (int.from_bytes(header[6:8], 'big') & 0x3fff):
                invalid_lengths += 1
            elif proto in (6, 17):
                payload = length - ihl - transport_header
                kind = 'udp' if proto == 17 else ('tcp_data' if payload else 'tcp_nondata')
                counts[kind][length] += 1
                payload_bytes[kind] += payload
    if time.monotonic() >= report_at:
        report()
        report_at = time.monotonic() + 1
report()
observer.close()
