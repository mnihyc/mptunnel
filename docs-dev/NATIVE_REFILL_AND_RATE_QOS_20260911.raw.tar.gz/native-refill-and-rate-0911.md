# Native refill and scheduling-rate discriminator

Date:2026-09-11. Category: bounded recovery investigation, NOT release acceptance.
Base:61279f0, including efed8ec's20% defaults. Authoritative project:./.

## Ordinary native-refill pair

Both binaries built with cargo build --release -j4, no diagnostic feature.
Control source=61279f0; candidate=base plus native-refill-candidate-0911.patch.
Frozen binaries:bin/native-refill-{control,candidate}-20260911/mptunnel.
Candidate build1m36;31213336/31153088bytes control/candidate. File sizes are
identities for this record, not integrity or source-equivalence proof.
The patch contains all native/runtime/RFC/tests changes, no default-policy edit.
Real writer RED:next Original offset41 instead of0 under a shared native
reservation. Final targeted checks:167rootQUIC,30native stream,1realQuinn
connection lifecycle; the22server-stream subset is included in167.

Run once per executable, SERIAL and after the preceding driver exits:

```sh
env -u REFLECTION_NO_QOS -u REFLECTION_NO_BLACKHOLE \
 -u REFLECTION_ROUTED -u REFLECTION_SERVER_BINARY -u REFLECTION_CLIENT_BINARY \
 -u REFLECTION_NATIVE_TRACE -u REFLECTION_MIRROR_IMPAIRMENT \
 -u REFLECTION_SERVER_CONFIG -u REFLECTION_DIAG \
 REFLECTION_BINARY=/workspace/.tmp/reflection/bin/native-refill-control-20260911/mptunnel \
 REFLECTION_CLIENT_CONFIG=client-isolated-tcp47-quic46.toml \
 REFLECTION_LINK_RATE=200mbit REFLECTION_NO_LOSS=1 REFLECTION_NO_JITTER=1 \
 REFLECTION_MANAGEMENT=1 REFLECTION_TARGET_OBSERVE=1 \
 REFLECTION_TAG=isolated-tcp47-quic46-native-refill-control-0911 \
 python3 .tmp/reflection/run.py aggregate combined down
```

Candidate changes ONLY binary and tag control→candidate. Existing Docker
containers, driver, qdiscs and guards unchanged. Three TCP carriers on47,
one QUIC46;200Mbps each,DOWN70/UP30ms,no intentional loss/jitter. QUIC cut46
DOWN10Mbps15--25s; UDP blackhole30--33s. Native overflow loss may still occur.
All results retain full timing and telemetry. Driver exits0 after41.030/40.430s.

Control/candidate:whole215.861/220.382Mbps; healthy5--15=345.358/299.787;
QoS15--25=22.217/39.700; QoSinterior17--24=11.513/23.728. The latter average
includes a late75Mbps bin; most candidate cut bins remain14Mbps. Firstbody
.578205/.578357s; worstreadgap.579925/.317180s. Echo75/75 and80/80attempts,
p95.719443/.400327s,max1.587691/.634911s. No hidden unsuccessful attempts.
Sampled DOWN wire1,338,121,390/1,353,786,476B;UP18,894,216/21,210,504B.
Usefulbulk1,079,351,526/1,101,958,256B. RatioDOWNwire/useful1.240/1.229
includes shared control/echo/native overhead and mismatched final polling edge;
it is not exact payload-copy attribution. Sum only the two HTB class counters,
not parent/child qdiscs again. Peak server/client RSS294668/82764 versus
320808/99976KiB; final ps lifetime-average CPU110/44.6 versus138/47.1percent.
Neither CPU scalar proves saturation or a causal owner. Full per-second data
are in service.jsonl; there is no reliable instantaneous CPU attribution here.

Decision: withdraw. Some latency/end-of-cut benefit, but severe sustained
independent-TCP underuse remains; no promotion to UP or release. One-window
refill is not a small time bound: candidate native window rises49--55MB after
the cut. No tuning or unaccepted runtime stack follows. Exact patch reversed
with apply_patch;src/crates/RFC/manifests match61279f0 after withdrawal.

## Estimate mismatch, same ordinary control

During10MbpsQoS, capacity198.324776Mbps/pacing196.341528Mbps stay high.
Same native epoch16172795627604236234: ACK333914097→341907357B over native
sample timestamps17572786→24150875us =9.721072Mbps. Sample timestamps, not
management poll timestamps, define the interval. Native ACK payload includes
all connection streams/control, not one application's ordered goodput.
This proves a capacity/current-service mismatch, not that the observer invented
the controller model or that a scalar substitution alone repairs recovery.

## Scheduling-rate oracle (diagnostic only)

Apply native-rate-oracle-0911.patch to clean61279f0. Build ordinary release
mode, freeze bin/native-rate-oracle-20260911/mptunnel, then remove patch BEFORE
traffic. The binary deliberately substitutes an exported10Mbps bandwidth only
in server elapsed16--26s after its first native metrics call. The native BBR
bw, cwnd, pacing, gains and recovery are untouched. Startup absence is retained.
There is no production config knob; MPTUNNEL_LAB_ROLE identifies the endpoint.
The origin is not the probe clock: validate actual10Mbps exported samples
against tc and restrict the inference to their common interval, not edges.

Reuse the same command/profile, binary/tag native-rate-oracle-20260911 /
isolated-tcp47-quic46-native-rate-oracle-0911. Set REFLECTION_DIAG=1 and
REFLECTION_DIAG_EVENTS=none solely to pass existing per-process role environment;
the build has no lab-diagnostics feature/events. This is an intervention,
not an ordinary performance candidate or a valid NativeOperational adapter.
Expected information: correct exported rate with continued collapse disproves
rate substitution as a sufficient fix; restored service implicates its downstream
consumers. Neither outcome licenses a raw-sample estimator or a timer tweak.
Outcome CLOSED: build1m37, frozen binary31215968B, driverexit0/40.755594s.
The export is10Mbps in every server sample16.145--26.146s; physical10Mbps
samples15.145--24.146s. Compare their shared17--24s interior, not onset/exit.
Native pacing remains175.963--195.514Mbps, RTT grows.728→4.180s and flight
stays~5.13MB before shrinking. The diagnostic did not lower native CC/pacing.
Whole216.319Mbps, healthy333.580, QoS21.113, commoninterior18.249; firstbody
.583661s,maxbodygap.357242s. Correct scheduling rate does not restore the
healthy TCP cut's~180Mbps user service. This falsifies rate substitution as
the sufficient remedy for this reproduced collapse; it does not prove rates
are irrelevant or identify every coupled scheduling consequence.

Preserve the adverse interactive result:33successful exchanges, one3.005s
timeout beginning18.093s, then38scheduled attempts unavailable after the probe
disconnects at21.097s. Thus interactive_fail39 is NOT39 independent network
timeouts. Successful-only p95.349s excludes this timeout and is not a pass.
The diagnostic is not accepted runtime, and this one run does not attribute
the echo failure specifically to the override. Both endpoints' normal stop
logs are retained. The patch was removed before traffic; committed runtime
is unchanged. No new production estimator or knob survives.
