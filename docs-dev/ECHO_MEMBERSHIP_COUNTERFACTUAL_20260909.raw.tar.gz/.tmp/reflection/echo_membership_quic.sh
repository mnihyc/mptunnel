#!/usr/bin/env bash
set -euo pipefail
exec env MPTUNNEL_LAB_ECHO_QUIC_MEMBERSHIP=1 \
  /workspace/.tmp/reflection/bin/echo-membership-20260909/mptunnel "$@"
